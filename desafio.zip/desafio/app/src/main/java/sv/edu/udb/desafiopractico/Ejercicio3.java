package sv.edu.udb.desafiopractico;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Ejercicio3 extends AppCompatActivity {

    private EditText empleado1;
    private EditText empleado2;
    private EditText empleado3;
    private EditText puesto1;
    private EditText puesto2;
    private EditText puesto3;
    private EditText horaslaboradas1;
    private EditText horaslaboradas2;
    private EditText horaslaboradas3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio3);
        empleado1 = (EditText) findViewById(R.id.etEmpleado1);
        empleado2 = (EditText) findViewById(R.id.etEmpleado2);
        empleado3 = (EditText) findViewById(R.id.etEmpleado3);
        puesto1 = (EditText) findViewById(R.id.etPuesto1);
        puesto2 = (EditText) findViewById(R.id.etPuesto2);
        puesto3 = (EditText) findViewById(R.id.etPuesto3);
        horaslaboradas1 = (EditText) findViewById(R.id.etHorasLaboradas1);
        horaslaboradas2 = (EditText) findViewById(R.id.etHorasLaboradas2);
        horaslaboradas3 = (EditText) findViewById(R.id.etHorasLaboradas3);
    }

    public void Salario(View v){
        Intent intent = new Intent(this, SalariosCalculo.class);
        String emp1 = this.empleado1.getText().toString();
        String emp2 = this.empleado2.getText().toString();
        String emp3 = this.empleado3.getText().toString();
        String[] empleados = new String[]{emp1, emp2, emp3 };

        String plaza1 = this.puesto1.getText().toString();
        String plaza2 = this.puesto2.getText().toString();
        String plaza3 = this.puesto3.getText().toString();
        String[] plazas = new String[]{plaza1, plaza2, plaza3 };

        try
        {
            Integer horas1 = Integer.parseInt(this.horaslaboradas1.getText().toString());
            Integer horas2 = Integer.parseInt(this.horaslaboradas2.getText().toString());
            Integer horas3 = Integer.parseInt(this.horaslaboradas3.getText().toString());
            Integer[] horaslaboradas = new Integer[]{horas1, horas2, horas3 };

            if((horas1 < 0) || (horas2 < 0) || (horas3 < 0))
            {
                Toast.makeText(this, "Ingrese horas válidas.", Toast.LENGTH_SHORT).show();
            }
            else
            {
                List<Double> salarios = new ArrayList<>();
                List<Double> descisss = new ArrayList<>();
                List<Double> descafp = new ArrayList<>();
                List<Double> descrenta = new ArrayList<>();

                for(int i = 0; i < 3; i++)
                {
                    Double salario = 0.0;
                    if(horaslaboradas[i] < 160) salario = horaslaboradas[i] * 9.75;
                    else
                    {
                        Integer extra = horaslaboradas[i] - 160;
                        salario = (160 * 9.75) + (extra * 11.50);
                    }

                    Double isss = salario * 0.0525;
                    descisss.add(isss);
                    Double afp = salario * 0.0688;
                    descafp.add(afp);
                    Double renta = salario * 0.1;
                    descrenta.add(renta);

                    Double total_desc = isss + afp + renta;
                    Double sal_total = salario - total_desc;

                    if(plazas[0] == "Gerente" && plazas[1] == "Asistente" && plazas[0] == "Secretaria")
                    {
                        salarios.add(sal_total);
                        continue;
                    }
                    else if(plazas[i] == "Gerente")
                    {
                        sal_total += sal_total * 0.1;
                    }
                    else if(plazas[i] == "Asistente")
                    {
                        sal_total += sal_total * 0.05;
                    }
                    else
                    {
                        sal_total += sal_total * 0.03;
                    }
                    salarios.add(sal_total);
                }

                Double mayor = Collections.max(salarios);
                Double menor = Collections.min(salarios);
                Integer posicionmayor = salarios.indexOf(mayor);
                Integer posicionmenor = salarios.indexOf(menor);
                String mayorEmpleado = empleados[posicionmayor];
                String menorEmpleado = empleados[posicionmenor];
                Integer mayores = 0;
                for (int i = 0; i < 3; i++)
                {
                    if (salarios.get(i) > 300.00) mayores++;
                }

                Bundle b = new Bundle();
                b.putSerializable("descisss", (Serializable)descisss);
                b.putSerializable("descafp", (Serializable)descafp);
                b.putSerializable("descrenta", (Serializable)descrenta);
                b.putSerializable("salarios", (Serializable)salarios);
                intent.putExtra("empleados", empleados);
                intent.putExtras(b);
                intent.putExtra("salmax", mayor);
                intent.putExtra("salmin", menor);
                intent.putExtra("mayor", mayores);
                intent.putExtra("mayorempl", mayorEmpleado);
                intent.putExtra("menorempl", menorEmpleado);
                startActivity(intent);
            }
        }
        catch (Exception e)
        {
            System.out.println("Error " + e.getMessage());
            Toast.makeText(this, "Ingrese horas válidas.", Toast.LENGTH_SHORT).show();
        }
    }
}