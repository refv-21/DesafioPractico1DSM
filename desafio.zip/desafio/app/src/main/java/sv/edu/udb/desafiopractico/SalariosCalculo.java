package sv.edu.udb.desafiopractico;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class SalariosCalculo extends AppCompatActivity {

    private TextView nomemp1, nomemp2, nomemp3, descisss1, descisss2, descisss3, descafp1, descafp2, descafp3, descrenta1, descrenta2, descrenta3, maxsalario, minsalario, mayores, sal1, sal2, sal3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_salarios_calculo);

        Intent intent = getIntent();
        Bundle b = intent.getExtras();
        ArrayList<Double> descisss = (ArrayList<Double>) b.getSerializable("descisss");
        ArrayList<Double> salarios = (ArrayList<Double>) b.getSerializable("salarios");
        ArrayList<Double> descafp = (ArrayList<Double>) b.getSerializable("descafp");
        ArrayList<Double> descrenta = (ArrayList<Double>) b.getSerializable("descrenta");
        String[] empleados = intent.getStringArrayExtra("empleados");

        Double salmax = intent.getDoubleExtra("salmax", 0.0);
        Double salmin = intent.getDoubleExtra("salmin", 0.0);
        Integer mayor = intent.getIntExtra("mayor", 0);
        String mayorempl = intent.getStringExtra("mayorempl");
        String menorempl = intent.getStringExtra("menorempl");

        nomemp1 = findViewById(R.id.tvEmpleado1);
        nomemp1.setText(empleados[0]);
        nomemp2 = findViewById(R.id.tvEmpleado2);
        nomemp2.setText(empleados[1]);
        nomemp3 = findViewById(R.id.tvEmpleado3);
        nomemp3.setText(empleados[2]);

        descisss1 = findViewById(R.id.tvIsss1);
        descisss1.setText(String.format("%.2f", descisss.get(0)));
        descisss2 = findViewById(R.id.tvIsss2);
        descisss2.setText(String.format("%.2f", descisss.get(1)));
        descisss3 = findViewById(R.id.tvIsss3);
        descisss3.setText(String.format("%.2f", descisss.get(2)));

        descafp1 = findViewById(R.id.tvAfp1);
        descafp1.setText(String.format("%.2f", descafp.get(0)));
        descafp2 = findViewById(R.id.tvAfp2);
        descafp2.setText(String.format("%.2f", descafp.get(1)));
        descafp3 = findViewById(R.id.tvAfp3);
        descafp3.setText(String.format("%.2f", descafp.get(2)));

        descrenta1 = findViewById(R.id.tvRenta1);
        descrenta1.setText(String.format("%.2f", descrenta.get(0)));
        descrenta2 = findViewById(R.id.tvRenta2);
        descrenta2.setText(String.format("%.2f", descrenta.get(1)));
        descrenta3 = findViewById(R.id.tvRenta3);
        descrenta3.setText(String.format("%.2f", descrenta.get(2)));

        sal1 = findViewById(R.id.tvSalario1);
        sal1.setText(String.format("%.2f", salarios.get(0)));
        sal2 = findViewById(R.id.tvSalario2);
        sal2.setText(String.format("%.2f", salarios.get(1)));
        sal3 = findViewById(R.id.tvSalario3);
        sal3.setText(String.format("%.2f", salarios.get(2)));

        maxsalario = findViewById(R.id.tvMax_sal);
        maxsalario.setText(String.format("El salario máximo es de %.2f, obtenido por %s", salmax, mayorempl));
        minsalario = findViewById(R.id.tvMin_sal);
        minsalario.setText(String.format("El salario mínimo es de %.2f, obtenido por %s", salmin, menorempl));
        mayores = findViewById(R.id.tvMayores);
        mayores.setText(String.format("%d empleados tienen un salario mayor a 300", mayor));
    }
}